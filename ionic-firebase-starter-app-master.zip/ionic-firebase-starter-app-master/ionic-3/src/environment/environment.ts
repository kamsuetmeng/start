export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBvJ0ZWfd2GcIpKgdcIaZKJ6ohLW_E7DOs",
    authDomain: "fir-storage-login.firebaseapp.com",
    databaseURL: "https://fir-storage-login.firebaseio.com",
    projectId: "firebase-storage-login",
    storageBucket: "firebase-storage-login.appspot.com",
    messagingSenderId: "803036592201"
  }
};
