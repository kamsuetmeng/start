export const environment = {
  production: true,
  firebase : {
   apiKey: "YOUR_CREDENTIALS_HERE",
   authDomain: "YOUR_CREDENTIALS_HERE",
   databaseURL: "YOUR_CREDENTIALS_HERE",
   projectId: "YOUR_CREDENTIALS_HERE",
   storageBucket: "YOUR_CREDENTIALS_HERE",
   messagingSenderId: "YOUR_CREDENTIALS_HERE"
 }
};
